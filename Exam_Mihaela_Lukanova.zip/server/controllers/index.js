let homeController = require('./home-controller')
let carsController = require('./cars-controller')

module.exports = {
  home: homeController,
  cars: carsController
}
